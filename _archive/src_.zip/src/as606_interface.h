#ifndef AS606_INTERFACE_H
#define AS606_INTERFACE_H

#include <Adafruit_Fingerprint.h>
#include "wiring_private.h"  // For pinPeripheral()

// Feather M4 custom UART on A0/A1 using SERCOM0.
// Board mapping (variant.cpp): A0 = PA02, A1 = PA05.
#define FINGERPRINT_BAUD 57600

// Uart(sercom, rxPin, txPin, rxPad, txPad)
// Sensor TX -> A1 (MCU RX), Sensor RX -> A0 (MCU TX)
static Uart SensorUart(&sercom0, A1, A0, SERCOM_RX_PAD_1, UART_TX_PAD_0);
static Adafruit_Fingerprint finger = Adafruit_Fingerprint(&SensorUart);

// SAMD51 uses split SERCOM IRQ vectors. All must forward to IrqHandler().
void SERCOM0_0_Handler() { SensorUart.IrqHandler(); }
void SERCOM0_1_Handler() { SensorUart.IrqHandler(); }
void SERCOM0_2_Handler() { SensorUart.IrqHandler(); }
void SERCOM0_3_Handler() { SensorUart.IrqHandler(); }

/**
 * AS606 Fingerprint Sensor Interface
 * Ported from working ESP32 code to Feather M4
 * Uses SERCOM0 software UART on A0 (TX/PAD0) and A1 (RX/PAD1)
 * Requires pinPeripheral() calls to configure pads properly
 */
class AS606Interface {
private:
  bool initialized;

public:
  AS606Interface() : initialized(false) {}

  bool begin() {
    Serial.println(F("[AS606] Initializing sensor on A0/A1 (SERCOM0)..."));

    const uint32_t baud_list[] = {57600, 115200, 9600, 19200};
    const EPioType mux_list[] = {PIO_SERCOM_ALT, PIO_SERCOM};
    const char* mux_name[] = {"PIO_SERCOM_ALT", "PIO_SERCOM"};

    for (uint8_t m = 0; m < 2; m++) {
      pinPeripheral(A0, mux_list[m]);  // TX on A0 (PA02)
      pinPeripheral(A1, mux_list[m]);  // RX on A1 (PA05)

      Serial.print(F("[AS606] Trying mux: "));
      Serial.println(mux_name[m]);

      for (uint8_t i = 0; i < 4; i++) {
        uint32_t baud = baud_list[i];
        Serial.print(F("[AS606]   Trying baud: "));
        Serial.println(baud);

        SensorUart.begin(baud);
        delay(120);
        finger.begin(baud);
        delay(120);

        if (finger.verifyPassword()) {
          Serial.print(F("[AS606] Sensor handshake OK with "));
          Serial.print(mux_name[m]);
          Serial.print(F(" @ "));
          Serial.println(baud);

          finger.getTemplateCount();
          Serial.print(F("[AS606] Sensor connected. Templates: "));
          Serial.println(finger.templateCount);
          initialized = true;
          return true;
        }
      }
    }

    Serial.println(F("[AS606] Sensor handshake failed on A0/A1."));
    Serial.println(F("[AS606] Wiring required: sensor TX->A1, sensor RX->A0, 3.3V power."));
    initialized = false;
    return false;
  }

  bool isInitialized() const {
    return initialized;
  }

  uint8_t getImage() {
    if (!initialized) {
      Serial.println(F("[AS606] ERROR: Sensor not initialized!"));
      return FINGERPRINT_NOFINGER;
    }
    
    Serial.println(F("[AS606] Waiting for fingerprint..."));
    finger.LEDcontrol(FINGERPRINT_LED_ON, 0, FINGERPRINT_LED_BLUE);
    
    uint8_t p = finger.getImage();
    
    finger.LEDcontrol(FINGERPRINT_LED_OFF, 0, FINGERPRINT_LED_BLUE);
    
    if (p == FINGERPRINT_OK) {
      Serial.println(F("[AS606] Image captured!"));
    } else {
      Serial.print(F("[AS606] Image capture failed: 0x"));
      Serial.println(p, HEX);
    }
    
    return p;
  }

  uint8_t image2Tz(uint8_t slot = 1) {
    if (!initialized) {
      Serial.println(F("[AS606] ERROR: Sensor not initialized!"));
      return FINGERPRINT_IMAGEFAIL;
    }
    
    Serial.print(F("[AS606] Converting image to template (slot "));
    Serial.print(slot);
    Serial.println(F(")..."));
    
    uint8_t p = finger.image2Tz(slot);
    
    if (p == FINGERPRINT_OK) {
      Serial.println(F("[AS606] Template created!"));
    } else {
      Serial.print(F("[AS606] Template failed: 0x"));
      Serial.println(p, HEX);
    }
    
    return p;
  }

  uint16_t fingerSearch() {
    if (!initialized) {
      Serial.println(F("[AS606] ERROR: Sensor not initialized!"));
      return 0;
    }
    
    Serial.println(F("[AS606] Searching database..."));
    
    uint8_t p = finger.fingerSearch();
    
    if (p == FINGERPRINT_OK) {
      Serial.print(F("[AS606] ✓ MATCH! ID: "));
      Serial.print(finger.fingerID);
      Serial.print(F(" Confidence: "));
      Serial.println(finger.confidence);
      return finger.fingerID;
    } else if (p == FINGERPRINT_NOTFOUND) {
      Serial.println(F("[AS606] No match found."));
      return 0;
    } else {
      Serial.print(F("[AS606] Search error: 0x"));
      Serial.println(p, HEX);
      return 0;
    }
  }

  uint16_t getLastMatchID() const {
    if (!initialized) return 0;
    return finger.fingerID;
  }

  uint16_t getLastConfidence() const {
    if (!initialized) return 0;
    return finger.confidence;
  }

  uint16_t getTemplateCount() {
    if (!initialized) {
      Serial.println(F("[AS606] ERROR: Sensor not initialized!"));
      return 0;
    }
    
    finger.getTemplateCount();
    Serial.print(F("[AS606] Templates: "));
    Serial.println(finger.templateCount);
    
    return finger.templateCount;
  }

  void printLastResponseCode() {
    Serial.println(F("[AS606] Check serial output for error details."));
  }

  ~AS606Interface() {}
};

#endif  // AS606_INTERFACE_H
