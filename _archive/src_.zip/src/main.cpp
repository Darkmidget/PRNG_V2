/***************************************************
  Feather M4 + Fingerprint Sensor + Game of Life
  
  Integrated Workflow:
  1. Display runs Game of Life animation
  2. While animating, passively listen for fingerprint
  3. On detection: pause, clear grid, capture fingerprint
  4. Send fingerprint data to FPGA via Serial2
  5. Receive random seed from FPGA
  6. Reinitialize Game of Life with new seed
  7. Resume animation
  
  🔧 DUAL SERIAL CONFIGURATION:
  ========================================
  Serial (USB @ 115200):     Debug console
  Serial1 (D0/D1 @ 57600):   Fingerprint sensor (AS606)
  Serial2 (D12/D13 @ 115200): FPGA communication
  
  📋 CONNECTIONS:
  Fingerprint Sensor:
    - Sensor TX (white) → D0 (RX/Serial1)
    - Sensor RX (green) → D1 (TX/Serial1)
    - GND → GND
    - 3V3 → 3V3
  
  FPGA (Serial2):
    - FPGA TX → PA10 (D12) / Serial2 RX
    - FPGA RX → PA11 (D13) / Serial2 TX
    - GND → GND
    - Power → As required
  
  Display (SPI):
    - Configured in display_renderer.h
 ****************************************************/

#include <Adafruit_Fingerprint.h>
#include <Adafruit_GFX.h>
#include <Adafruit_HX8357.h>
#include "gameoflife.h"
#include "display_renderer.h"
#include "fpga_serial.h"

// ========================================
// GLOBAL OBJECTS & STATE
// ========================================

// Fingerprint sensor on Serial1 (D0/D1 @ 57600)
Adafruit_Fingerprint finger = Adafruit_Fingerprint(&Serial1);

// Display renderer (SPI pins configured in constructor)
DisplayRenderer display(10, 9);  // CS=D10, DC=D9 (adjust if needed)

// Game of Life simulator
GameOfLife gameOfLife;

// FPGA serial interface
FPGASerial fpgaSerial;

// Animation state machine
enum AnimationState {
  STATE_RUNNING,      // Game of Life animating normally
  STATE_WAITING_FINGER,  // Animation paused, scanning for fingerprint
  STATE_PROCESSING,   // Captured fingerprint, sending to FPGA
  STATE_RESTARTING    // Received seed, reinitializing grid
};

// Current animation state
AnimationState currentState = STATE_RUNNING;

// Timing controls
uint32_t lastGameUpdateTime = 0;
uint32_t lastDisplayUpdateTime = 0;
uint32_t stateChangeTime = 0;
const uint32_t GAME_UPDATE_INTERVAL = 300;  // Update Game of Life every 300ms
const uint32_t DISPLAY_UPDATE_INTERVAL = 100;  // Render display every 100ms
const uint32_t FINGERPRINT_SCAN_TIMEOUT = 5000;  // Wait 5 seconds for finger
const uint32_t STATE_TRANSITION_DELAY = 2000;  // 2 second delay when restarting

// Debounce fingerprint matches to prevent rapid re-triggers
uint32_t lastFingerprintMatchTime = 0;
const uint32_t DEBOUNCE_DELAY = 5000;  // 5 second grace period after match

// ========================================
// FINGERPRINT SENSOR FUNCTIONS
// ========================================

/**
 * Initialize the fingerprint sensor on Serial1
 */
bool initializeFingerprint() {
  Serial.println(F("\n[SETUP] Initializing fingerprint sensor..."));
  
  Serial1.begin(57600);
  delay(500);
  
  finger.begin(57600);
  delay(500);
  
  if (!finger.verifyPassword()) {
    Serial.println(F("[ERROR] Fingerprint sensor not found!"));
    Serial.println(F("[CHECK] Verify D0/D1 connections:"));
    Serial.println(F("        D0 (RX) <- Sensor TX (white)"));
    Serial.println(F("        D1 (TX) -> Sensor RX (green)"));
    Serial.println(F("        GND -> GND, 3V3 -> 3V3"));
    return false;
  }
  
  finger.getTemplateCount();
  Serial.print(F("[SUCCESS] Fingerprint sensor initialized! Templates: "));
  Serial.print(finger.templateCount);
  Serial.print(F(" / Capacity: "));
  Serial.println(finger.capacity);
  
  return true;
}

/**
 * Attempt to capture and identify a fingerprint
 * Returns fingerprint ID (1-127) on match, -1 on failure
 */
int16_t captureFingerprint(uint8_t &confidence) {
  // Get fingerprint image
  uint8_t p = finger.getImage();
  
  if (p == FINGERPRINT_NOFINGER) {
    return -1;  // No finger detected
  } else if (p != FINGERPRINT_OK) {
    Serial.print(F("[FP] Image capture error: 0x"));
    Serial.println(p, HEX);
    return -1;
  }
  
  Serial.println(F("[FP] Image captured!"));
  delay(100);
  
  // Convert image to fingerprint template
  p = finger.image2Tz();
  if (p != FINGERPRINT_OK) {
    Serial.print(F("[FP] Conversion error: 0x"));
    Serial.println(p, HEX);
    return -1;
  }
  
  Serial.println(F("[FP] Image converted to template!"));
  delay(100);
  
  // Search for match in database
  p = finger.fingerFastSearch();
  
  if (p == FINGERPRINT_OK) {
    confidence = finger.confidence;
    int16_t matchID = finger.fingerID;
    
    Serial.print(F("[FP] ✓ MATCH FOUND - ID: "));
    Serial.print(matchID);
    Serial.print(F(", Confidence: "));
    Serial.println(confidence);
    
    return matchID;
  } else if (p == FINGERPRINT_NOTFOUND) {
    Serial.println(F("[FP] ✗ No match found - finger not recognized"));
    return -1;
  } else {
    Serial.print(F("[FP] Search error: 0x"));
    Serial.println(p, HEX);
    return -1;
  }
}

// ========================================
// STATE MACHINE HANDLERS
// ========================================

/**
 * STATE_RUNNING: Game of Life animating normally
 * Passive listening for fingerprint press
 */
void handleRunningState() {
  uint32_t now = millis();
  
  // Update Game of Life at regular intervals
  if (now - lastGameUpdateTime >= GAME_UPDATE_INTERVAL) {
    gameOfLife.update();
    lastGameUpdateTime = now;
  }
  
  // Render display at regular intervals
  if (now - lastDisplayUpdateTime >= DISPLAY_UPDATE_INTERVAL) {
    display.renderGrid(gameOfLife);
    display.updateInfoPanel(gameOfLife.getGeneration(), "Running", 0);
    lastDisplayUpdateTime = now;
  }
  
  // Passive check: probe the sensor without LED activation
  // If sensor has detected something, transition to WAITING_FINGER
  uint8_t p = finger.getImage();
  if (p == FINGERPRINT_OK) {
    // Sensor detected a finger approaching
    if (millis() - lastFingerprintMatchTime > DEBOUNCE_DELAY) {
      Serial.println(F("\n[STATE] Fingerprint detected! Transitioning to WAITING_FINGER..."));
      currentState = STATE_WAITING_FINGER;
      stateChangeTime = millis();
      
      // Clear grid for visual feedback
      display.renderGrid(gameOfLife);  // Will show empty grid when reinit'd
    }
  }
}

/**
 * STATE_WAITING_FINGER: Animation paused, actively scan for fingerprint
 * Wait up to FINGERPRINT_SCAN_TIMEOUT for a valid match
 */
void handleWaitingFingerState() {
  uint32_t now = millis();
  uint32_t elapsed = now - stateChangeTime;
  
  // Display status
  if (now - lastDisplayUpdateTime >= DISPLAY_UPDATE_INTERVAL) {
    display.updateInfoPanel(gameOfLife.getGeneration(), "Waiting for FP", 0);
    lastDisplayUpdateTime = now;
  }
  
  // Try to capture fingerprint
  uint8_t confidence = 0;
  int16_t fingerprintID = captureFingerprint(confidence);
  
  if (fingerprintID > 0) {
    // Successfully matched!
    Serial.println(F("[STATE] Valid fingerprint matched! Transitioning to PROCESSING..."));
    lastFingerprintMatchTime = now;
    currentState = STATE_PROCESSING;
    stateChangeTime = now;
    
    // Store match data for next state
    // (Using global variables for simplicity; could use a struct)
  } else {
    // Check timeout
    if (elapsed > FINGERPRINT_SCAN_TIMEOUT) {
      Serial.println(F("[STATE] Fingerprint scan timeout. Returning to RUNNING..."));
      currentState = STATE_RUNNING;
      stateChangeTime = now;
      lastGameUpdateTime = now;
      lastDisplayUpdateTime = now;
    }
  }
  
  delay(50);  // Brief delay to prevent hammering the sensor
}

/**
 * STATE_PROCESSING: Captured fingerprint, send to FPGA, wait for seed
 */
void handleProcessingState() {
  uint32_t now = millis();
  
  // Re-capture fingerprint for ID and confidence (since we stored in captureFingerprint above)
  // For now, we'll do a real quick capture
  uint8_t confidence = 0;
  int16_t fingerprintID = captureFingerprint(confidence);
  
  if (fingerprintID > 0) {
    Serial.println(F("[STATE] Sending fingerprint to FPGA..."));
    
    // Send fingerprint data to FPGA
    fpgaSerial.sendFingerprintData((uint16_t)fingerprintID, (uint16_t)confidence);
    
    // Wait for seed response from FPGA
    uint16_t newSeed = fpgaSerial.receiveSeedFromFPGA();
    
    Serial.print(F("[STATE] Received seed: "));
    Serial.println(newSeed);
    
    // Reinitialize Game of Life with new seed
    gameOfLife.initialize(newSeed);
    
    Serial.println(F("[STATE] Game of Life reinitialized. Transitioning to RESTARTING..."));
    currentState = STATE_RESTARTING;
    stateChangeTime = now;
    lastGameUpdateTime = now;
    lastDisplayUpdateTime = now;
  } else {
    // Fingerprint matching failed - return to RUNNING
    Serial.println(F("[STATE] Fingerprint matching failed. Returning to RUNNING..."));
    currentState = STATE_RUNNING;
    stateChangeTime = now;
    lastGameUpdateTime = now;
    lastDisplayUpdateTime = now;
  }
}

/**
 * STATE_RESTARTING: Display brief pause, then resume animation
 */
void handleRestartingState() {
  uint32_t now = millis();
  uint32_t elapsed = now - stateChangeTime;
  
  // Display "restarting" message
  display.updateInfoPanel(gameOfLife.getGeneration(), "Restarting", 0);
  
  // Show grid (which is now fresh from initialize)
  display.renderGrid(gameOfLife);
  
  // After brief delay, transition back to RUNNING
  if (elapsed > STATE_TRANSITION_DELAY) {
    Serial.println(F("[STATE] Transition delay complete. Returning to RUNNING..."));
    currentState = STATE_RUNNING;
    stateChangeTime = now;
    lastGameUpdateTime = now;
    lastDisplayUpdateTime = now;
  }
}

// ========================================
// SETUP & LOOP
// ========================================

void setup() {
  delay(1000);
  
  // Initialize debug serial (USB)
  Serial.begin(115200);
  delay(1000);
  
  Serial.println(F("\n\n============================================"));
  Serial.println(F("Feather M4 + Fingerprint + Game of Life"));
  Serial.println(F("============================================\n"));
  
  // Initialize fingerprint sensor
  if (!initializeFingerprint()) {
    Serial.println(F("[ERROR] Fingerprint sensor failed! Halting."));
    while (1) {
      delay(1000);
    }
  }
  
  // Initialize FPGA serial interface
  fpgaSerial.begin();
  
  // Initialize display
  Serial.println(F("[SETUP] Initializing display..."));
  if (!display.begin()) {
    Serial.println(F("[WARNING] Display initialization had issues, but continuing..."));
  }
  
  // Initialize Game of Life with random seed
  uint16_t initialSeed = (uint16_t)random(65536);
  Serial.print(F("[SETUP] Initializing Game of Life with seed: "));
  Serial.println(initialSeed);
  gameOfLife.initialize(initialSeed);
  
  // Initialize timing
  lastGameUpdateTime = millis();
  lastDisplayUpdateTime = millis();
  stateChangeTime = millis();
  
  Serial.println(F("[SETUP] Initialization complete! Starting animation...\n"));
  Serial.println(F("Place your finger on the sensor to capture a fingerprint."));
  Serial.println(F("============================================\n"));
}

void loop() {
  // Route to appropriate state handler
  switch (currentState) {
    case STATE_RUNNING:
      handleRunningState();
      break;
    
    case STATE_WAITING_FINGER:
      handleWaitingFingerState();
      break;
    
    case STATE_PROCESSING:
      handleProcessingState();
      break;
    
    case STATE_RESTARTING:
      handleRestartingState();
      break;
    
    default:
      currentState = STATE_RUNNING;
      break;
  }
}
